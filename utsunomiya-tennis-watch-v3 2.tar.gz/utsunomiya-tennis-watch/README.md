# 宇都宮テニス空き通知アプリ

屋板テニスコート（1030）と宮原運動公園テニスコート（1032）の土日午前（8:00〜12:00）を監視します。

## 重要
このプロジェクトは「監視プログラム」＋「iPhone用PWA画面」の土台です。監視を24時間動かすにはPC/サーバー上でNode.jsを常時起動してください。

### 監視
```bash
cd monitor
npm install
npx playwright install --with-deps chromium
npm start
```
10分ごとに監視します。初回状態を保存し、その後に新しく利用可能になった枠だけを通知対象にします。

Discord通知を使う場合:
```bash
DISCORD_WEBHOOK_URL='https://discord.com/api/webhooks/...' npm start
```

1回だけ確認:
```bash
npm run once
```

## 監視対象
- 屋板運動場 テニスコート: 施設ID 1030
- 宮原運動公園テニスコート: 施設ID 1032
- 土曜・日曜
- 8:00〜12:00
- 標準10分間隔

## iPhone
`app/index.html` はホーム画面に追加できるPWA用の簡易画面です。実際のiPhoneプッシュ通知まで行うにはHTTPS配信とWeb Push購読処理を追加してください。
