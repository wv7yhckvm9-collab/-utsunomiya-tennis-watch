# 宇都宮テニス空き通知
GitHub Pagesのルートに `index.html` / `manifest.json` / `sw.js` を置く構成です。

まず「この端末で通知をテスト」でiPhone側の通知許可を確認します。
実際の10分間隔監視・新規空き枠通知は、別途監視サーバー（またはGitHub Actions等）を接続します。
